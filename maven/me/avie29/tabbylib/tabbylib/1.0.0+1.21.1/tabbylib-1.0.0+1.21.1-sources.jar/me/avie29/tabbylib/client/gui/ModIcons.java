package me.avie29.tabbylib.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import me.avie29.tabbylib.TabbyLib;
import me.avie29.tabbylib.api.TabbyConfig;
import me.avie29.tabbylib.compat.McCompat;
import me.avie29.tabbylib.platform.ModInfo;
import net.minecraft.class_1011;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.jspecify.annotations.Nullable;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/** Loads the icon from the mod metadata once per mod and keeps it as texture. */
public final class ModIcons {
	private static final Map<String, Optional<Icon>> CACHE = new HashMap<>();

	/** A loaded icon texture and its size in pixels. */
	public record Icon(class_2960 texture, int width, int height) {
		public void draw(class_332 graphics, int x, int y, int size) {
			RenderSystem.enableBlend();
			graphics.method_25293(this.texture, x, y, size, size, 0, 0, this.width, this.height, this.width, this.height);
			RenderSystem.disableBlend();
		}
	}

	private ModIcons() {
	}

	public static @Nullable Icon get(TabbyConfig config) {
		if (config.getCustomIcon() != null) {
			// Custom icons are assumed to be square
			return new Icon(config.getCustomIcon(), 64, 64);
		}
		return CACHE.computeIfAbsent(config.getModId(), modId -> config.modInfo().flatMap(ModIcons::load)).orElse(null);
	}

	private static Optional<Icon> load(ModInfo mod) {
		if (mod.iconPath().isEmpty()) {
			return Optional.empty();
		}
		try {
			Optional<InputStream> stream = mod.resources().open(mod.iconPath().get());
			if (stream.isEmpty()) {
				return Optional.empty();
			}
			class_1011 image;
			try (InputStream input = stream.get()) {
				image = class_1011.method_4309(input);
			}
			String safeId = mod.id().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_.-]", "_");
			class_2960 id = TabbyLib.id("mod_icon/" + safeId);
			Icon icon = new Icon(id, image.method_4307(), image.method_4323());
			class_310.method_1551().method_1531().method_4616(id, McCompat.texture(image));
			return Optional.of(icon);
		} catch (Exception e) {
			TabbyLib.LOGGER.warn("Could not load icon of {}", mod.id(), e);
			return Optional.empty();
		}
	}
}
