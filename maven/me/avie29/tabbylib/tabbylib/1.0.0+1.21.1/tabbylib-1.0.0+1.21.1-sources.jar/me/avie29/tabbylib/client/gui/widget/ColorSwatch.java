package me.avie29.tabbylib.client.gui.widget;

import java.util.function.IntSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_6382;

/** A clickable colored square. Transparent colors are drawn over a checkerboard. */
public class ColorSwatch extends class_4264 {
	private final IntSupplier color;
	private final Runnable onPress;

	public ColorSwatch(int size, IntSupplier color, Runnable onPress) {
		super(0, 0, size, size, class_2561.method_43471("tabbylib.color.pick"));
		this.color = color;
		this.onPress = onPress;
	}

	@Override
	public void method_25306() {
		this.onPress.run();
	}

	@Override
	protected void method_48579(class_332 graphics, int mouseX, int mouseY, float delta) {
		int x = this.method_46426();
		int y = this.method_46427();
		int outline = !this.field_22763 ? 0xFF555555 : this.method_25367() ? 0xFFFFFFFF : 0xFFA0A0A0;
		graphics.method_25294(x, y, x + this.field_22758, y + this.field_22759, outline);
		drawColor(graphics, x + 1, y + 1, x + this.field_22758 - 1, y + this.field_22759 - 1, this.color.getAsInt());
	}

	/** Fills a rectangle with the color over a checkerboard, so transparency is visible. */
	public static void drawColor(class_332 graphics, int x0, int y0, int x1, int y1, int argb) {
		checkerboard(graphics, x0, y0, x1, y1);
		graphics.method_25294(x0, y0, x1, y1, argb);
	}

	public static void checkerboard(class_332 graphics, int x0, int y0, int x1, int y1) {
		int cell = 4;
		graphics.method_25294(x0, y0, x1, y1, 0xFFFFFFFF);
		for (int cy = y0; cy < y1; cy += cell) {
			for (int cx = x0 + (((cy - y0) / cell) % 2) * cell; cx < x1; cx += cell * 2) {
				graphics.method_25294(cx, cy, Math.min(cx + cell, x1), Math.min(cy + cell, y1), 0xFFBFBFBF);
			}
		}
	}

	@Override
	protected void method_47399(class_6382 output) {
		this.method_37021(output);
	}
}
