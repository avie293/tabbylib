package me.avie29.tabbylib.api.option;

import net.minecraft.class_2477;

/** Checks whether a translation key exists in the current language. */
final class TranslationHelper {
	private TranslationHelper() {
	}

	static boolean exists(String key) {
		return class_2477.method_10517().method_4678(key);
	}
}
