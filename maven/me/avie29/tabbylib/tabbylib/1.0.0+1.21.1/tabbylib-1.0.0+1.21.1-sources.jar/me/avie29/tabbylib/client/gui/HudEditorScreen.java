package me.avie29.tabbylib.client.gui;

import me.avie29.tabbylib.TabbyLibConfig;
import me.avie29.tabbylib.api.HudPosition;
import me.avie29.tabbylib.api.HudPreview;
import me.avie29.tabbylib.api.option.HudPositionOption;
import me.avie29.tabbylib.client.gui.widget.TabbyButton;
import me.avie29.tabbylib.compat.McCompat;
import me.avie29.tabbylib.compat.TabbyScreen;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.jspecify.annotations.Nullable;

import java.util.List;

/**
 * Drag and drop editor for a {@link HudPositionOption} (legacy variant).
 * Snaps to the screen edges, the center and a grid. Hold Alt while dragging to place freely,
 * use the arrow keys to move by 1 pixel (10 with Shift).
 */
public class HudEditorScreen extends TabbyScreen {
	private static final int GUIDE_COLOR = 0x8033CCFF;
	private static boolean open;

	private final @Nullable class_437 parent;
	private final HudPositionOption option;
	/** Opened on its own (not from the config screen): "Done" saves right away. */
	private final boolean standalone;
	private final HudPreview preview;
	private final HudPosition initial;

	private boolean dragging;
	private int dragOffsetX;
	private int dragOffsetY;
	private boolean guideVertical;
	private boolean guideHorizontal;

	public HudEditorScreen(@Nullable class_437 parent, HudPositionOption option) {
		this(parent, option, false);
	}

	public HudEditorScreen(@Nullable class_437 parent, HudPositionOption option, boolean standalone) {
		super(class_2561.method_43469("tabbylib.hud.title", option.getName()));
		this.parent = parent;
		this.option = option;
		this.standalone = standalone;
		this.preview = option.createPreview();
		this.initial = option.getPending();
	}

	/** True while any HUD editor is open. Mods can skip drawing their real HUD element then. */
	public static boolean isOpen() {
		return open;
	}

	@Override
	protected void method_25426() {
		open = true;
		int buttonWidth = 70;
		int y = this.field_22790 - 28;
		int x = (this.field_22789 - buttonWidth * 3 - 8) / 2;
		TabbyButton reset = new TabbyButton(buttonWidth, 20, class_2561.method_43471("tabbylib.hud.reset"), () -> this.option.resetPending());
		TabbyButton cancel = new TabbyButton(buttonWidth, 20, class_2561.method_43471("gui.cancel"), () -> {
			this.option.setPending(this.initial);
			this.close(false);
		});
		TabbyButton done = new TabbyButton(buttonWidth, 20, class_2561.method_43471("gui.done"), () -> this.close(true));
		for (TabbyButton button : List.of(reset, cancel, done)) {
			button.method_48229(x, y);
			x += buttonWidth + 4;
			this.method_37063(button);
		}
	}

	@Override
	public void method_25432() {
		open = false;
	}

	@Override
	public void method_25419() {
		this.close(true);
	}

	private void close(boolean keep) {
		open = false;
		if (this.standalone) {
			if (keep && this.option.isDirty() && this.option.getConfig() != null) {
				this.option.commit();
				this.option.getConfig().save();
			} else {
				this.option.discard();
			}
		}
		McCompat.setScreen(this.parent);
	}

	@Override
	public boolean method_25421() {
		return false;
	}

	// ---------------------------------------------------------------- position helpers

	private int elementX() {
		return this.option.getPending().x(this.field_22789, this.preview.width());
	}

	private int elementY() {
		return this.option.getPending().y(this.field_22790, this.preview.height());
	}

	private boolean isOverElement(double mx, double my) {
		int x = this.elementX();
		int y = this.elementY();
		return mx >= x - 2 && mx < x + this.preview.width() + 2 && my >= y - 2 && my < y + this.preview.height() + 2;
	}

	private void moveTo(int x, int y) {
		this.option.setPending(HudPosition.fromAbsolute(x, y, this.field_22789, this.field_22790, this.preview.width(), this.preview.height()));
	}

	private int snap(int value, int max, boolean vertical, boolean free) {
		value = Math.max(0, Math.min(value, max));
		boolean guide = false;
		if (!free) {
			int distance = TabbyLibConfig.SNAP_DISTANCE.get();
			int best = value;
			int bestDistance = distance + 1;
			if (TabbyLibConfig.SNAP_EDGES.get()) {
				for (int target : new int[]{0, max, max / 2}) {
					int d = Math.abs(value - target);
					if (d <= distance && d < bestDistance) {
						best = target;
						bestDistance = d;
						guide = true;
					}
				}
			}
			if (!guide && TabbyLibConfig.SNAP_GRID.get()) {
				int grid = TabbyLibConfig.GRID_SIZE.get();
				int target = Math.round((float) value / grid) * grid;
				if (Math.abs(value - target) <= distance) {
					best = Math.min(target, max);
				}
			}
			value = best;
		}
		if (vertical) {
			this.guideHorizontal = guide;
		} else {
			this.guideVertical = guide;
		}
		return value;
	}

	// ---------------------------------------------------------------- input

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (button == class_3675.field_32000 && this.isOverElement(mouseX, mouseY)) {
			this.dragging = true;
			this.dragOffsetX = (int) mouseX - this.elementX();
			this.dragOffsetY = (int) mouseY - this.elementY();
			return true;
		}
		return super.method_25402(mouseX, mouseY, button);
	}

	@Override
	public boolean method_25403(double mouseX, double mouseY, int button, double dx, double dy) {
		if (this.dragging) {
			boolean free = class_437.method_25443();
			int maxX = Math.max(0, this.field_22789 - this.preview.width());
			int maxY = Math.max(0, this.field_22790 - this.preview.height());
			int x = this.snap((int) mouseX - this.dragOffsetX, maxX, false, free);
			int y = this.snap((int) mouseY - this.dragOffsetY, maxY, true, free);
			this.moveTo(x, y);
			return true;
		}
		return super.method_25403(mouseX, mouseY, button, dx, dy);
	}

	@Override
	public boolean method_25406(double mouseX, double mouseY, int button) {
		if (this.dragging && button == class_3675.field_32000) {
			this.dragging = false;
			this.guideHorizontal = false;
			this.guideVertical = false;
			return true;
		}
		return super.method_25406(mouseX, mouseY, button);
	}

	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers) {
		int step = class_437.method_25442() ? 10 : 1;
		int dx = keyCode == class_3675.field_31983 ? -step : keyCode == class_3675.field_31984 ? step : 0;
		int dy = keyCode == class_3675.field_31932 ? -step : keyCode == class_3675.field_31982 ? step : 0;
		if (dx != 0 || dy != 0) {
			this.moveTo(this.elementX() + dx, this.elementY() + dy);
			return true;
		}
		return super.method_25404(keyCode, scanCode, modifiers);
	}

	// ---------------------------------------------------------------- rendering

	@Override
	protected void drawBackground(class_332 graphics, int mouseX, int mouseY, float delta) {
		if (this.field_22787.field_1687 != null) {
			// Keep the world visible so the element can be placed in context
			graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0x30000000);
		} else {
			super.drawBackground(graphics, mouseX, mouseY, delta);
		}
	}

	@Override
	protected void renderContent(class_332 graphics, int mouseX, int mouseY, float delta) {
		if (TabbyLibConfig.SHOW_GRID.get() && TabbyLibConfig.SNAP_GRID.get()) {
			int grid = TabbyLibConfig.GRID_SIZE.get();
			for (int x = grid; x < this.field_22789; x += grid) {
				graphics.method_25294(x, 0, x + 1, this.field_22790, 0x18FFFFFF);
			}
			for (int y = grid; y < this.field_22790; y += grid) {
				graphics.method_25294(0, y, this.field_22789, y + 1, 0x18FFFFFF);
			}
		}

		int x = this.elementX();
		int y = this.elementY();
		int w = this.preview.width();
		int h = this.preview.height();

		if (this.dragging) {
			if (this.guideVertical) {
				int guideX = x + w / 2;
				graphics.method_25294(guideX, 0, guideX + 1, this.field_22790, GUIDE_COLOR);
			}
			if (this.guideHorizontal) {
				int guideY = y + h / 2;
				graphics.method_25294(0, guideY, this.field_22789, guideY + 1, GUIDE_COLOR);
			}
		}

		this.preview.render(graphics, x, y);
		boolean hovered = this.dragging || this.isOverElement(mouseX, mouseY);
		graphics.method_49601(x - 1, y - 1, w + 2, h + 2, hovered ? 0xFFFFFFFF : TabbyLibConfig.accentColor());

		graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 0xFFFFFFFF);
		graphics.method_27534(this.field_22793, class_2561.method_43471("tabbylib.hud.hint"), this.field_22789 / 2, 24, 0xFFAAAAAA);
		graphics.method_27534(this.field_22793, class_2561.method_43470(this.option.formatValue(this.option.getPending())), this.field_22789 / 2, this.field_22790 - 40, 0xFF808080);
	}
}
