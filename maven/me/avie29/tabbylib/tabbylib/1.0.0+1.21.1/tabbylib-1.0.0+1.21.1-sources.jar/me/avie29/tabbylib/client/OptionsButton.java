package me.avie29.tabbylib.client;

import me.avie29.tabbylib.TabbyLibConfig;
import me.avie29.tabbylib.api.TabbyLibApi;
import me.avie29.tabbylib.compat.McCompat;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;

/** The "Tabby Config..." button in the vanilla options screen. */
public final class OptionsButton {
	public static final int WIDTH = class_4185.field_39500 * 2 + 8;

	private OptionsButton() {
	}

	public static boolean enabled() {
		return TabbyLibConfig.OPTIONS_BUTTON.get() && !TabbyLibApi.getConfigs().isEmpty();
	}

	public static class_4185 create(class_437 parent) {
		return class_4185.method_46430(class_2561.method_43471("tabbylib.options_button"),
				button -> McCompat.setScreen(TabbyLibApi.createScreen(parent, null)))
			.method_46432(WIDTH)
			.method_46431();
	}

	/**
	 * For loaders that add the button with a screen event instead of the mixin: places it as a new row
	 * below the "Credits & Attribution" button, the last row of the option buttons.
	 */
	public static void addBelowGrid(class_437 screen, List<? extends class_364> widgets, Consumer<class_4185> add) {
		if (!enabled()) {
			return;
		}
		class_339 lastRow = find(widgets, "options.credits_and_attribution");
		class_339 firstColumn = find(widgets, "options.skinCustomisation");
		if (lastRow == null || firstColumn == null) {
			return;
		}
		int gridTop = firstColumn.method_46427();
		int buttonY = lastRow.method_46427() + 24;

		// Not enough room above the "Done" button: move the option grid up into the gap below the header
		class_339 done = find(widgets, "gui.done");
		if (done != null && buttonY + 24 > done.method_46427()) {
			int headerBottom = 0;
			for (class_364 listener : widgets) {
				if (listener instanceof class_339 widget && widget.method_46427() < gridTop) {
					headerBottom = Math.max(headerBottom, widget.method_46427() + widget.method_25364());
				}
			}
			int shift = Math.min(buttonY + 24 - done.method_46427(), Math.max(0, gridTop - headerBottom - 8));
			for (class_364 listener : widgets) {
				if (listener instanceof class_339 widget && widget.method_46427() >= gridTop && widget.method_46427() <= lastRow.method_46427()) {
					widget.method_46419(widget.method_46427() - shift);
				}
			}
			buttonY -= shift;
		}

		class_4185 button = create(screen);
		McCompat.setBounds(button, firstColumn.method_46426(), buttonY, lastRow.method_46426() + lastRow.method_25368() - firstColumn.method_46426(), 20);
		add.accept(button);
	}

	private static @Nullable class_339 find(List<? extends class_364> widgets, String translationKey) {
		for (class_364 listener : widgets) {
			if (listener instanceof class_339 widget
				&& widget.method_25369().method_10851() instanceof class_2588 contents
				&& contents.method_11022().equals(translationKey)) {
				return widget;
			}
		}
		return null;
	}
}
