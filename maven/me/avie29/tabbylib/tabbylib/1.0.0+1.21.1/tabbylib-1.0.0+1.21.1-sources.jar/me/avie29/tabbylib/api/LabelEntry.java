package me.avie29.tabbylib.api;

import net.minecraft.class_2561;

/** A (word wrapped) line of text between options. */
public record LabelEntry(class_2561 text) implements ConfigEntry {
}
