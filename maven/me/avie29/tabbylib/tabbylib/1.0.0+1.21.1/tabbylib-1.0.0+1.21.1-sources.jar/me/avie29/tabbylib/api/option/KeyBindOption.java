package me.avie29.tabbylib.api.option;

import com.google.gson.JsonElement;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.jspecify.annotations.Nullable;

/**
 * Shows a vanilla {@link class_304} in the config screen, so players can rebind it without
 * searching through the controls menu. The key itself is still stored in options.txt,
 * so it stays in sync with the vanilla controls screen.
 * <p>
 * Client only. Register the mapping with Fabric's {@code KeyMappingHelper} as usual.
 */
public class KeyBindOption extends Option<class_3675.class_306> {
	private final class_304 mapping;

	protected KeyBindOption(me.avie29.tabbylib.api.option.KeyBindOption.Builder builder) {
		super(builder);
		this.mapping = builder.mapping;
	}

	public static me.avie29.tabbylib.api.option.KeyBindOption.Builder builder(String key, class_304 mapping) {
		return new me.avie29.tabbylib.api.option.KeyBindOption.Builder(key, mapping);
	}

	public class_304 getMapping() {
		return this.mapping;
	}

	@Override
	public class_2561 getName() {
		class_2561 name = super.getName();
		// Falls back to the key mapping's own name when the config has no translation for it
		if (!TranslationHelper.exists(this.translationKey())) {
			return class_2561.method_43471(this.mapping.method_1431());
		}
		return name;
	}

	@Override
	public String formatValue(class_3675.class_306 value) {
		return value.method_27445().getString();
	}

	@Override
	protected boolean valueEquals(class_3675.@Nullable class_306 a, class_3675.@Nullable class_306 b) {
		return a == null || b == null ? a == b : a.method_1441().equals(b.method_1441());
	}

	@Override
	public @Nullable JsonElement toJson(class_3675.class_306 value) {
		return null;
	}

	@Override
	public class_3675.class_306 fromJson(JsonElement json) {
		return class_3675.method_15981(json.getAsString());
	}

	public static class Builder extends Option.Builder<class_3675.class_306, me.avie29.tabbylib.api.option.KeyBindOption.Builder> {
		private final class_304 mapping;

		protected Builder(String key, class_304 mapping) {
			super(key, mapping.method_1429());
			this.mapping = mapping;
			this.binding(
				() -> class_3675.method_15981(mapping.method_1428()),
				newKey -> {
					mapping.method_1422(newKey);
					class_304.method_1426();
					class_310.method_1551().field_1690.method_1640();
				}
			);
		}

		@Override
		public KeyBindOption build() {
			return new KeyBindOption(this);
		}
	}
}
