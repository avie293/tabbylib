package me.avie29.tabbylib.compat;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * Base class for TabbyLib screens that hides how the background is drawn in this Minecraft version (1.21.1).
 * Order: {@link #drawBackground} - {@link #renderContent} - widgets - {@link #renderForeground}.
 */
public abstract class TabbyScreen extends class_437 {
	protected TabbyScreen(class_2561 title) {
		super(title);
	}

	/** Blurred menu background by default. */
	protected void drawBackground(class_332 graphics, int mouseX, int mouseY, float delta) {
		super.method_25420(graphics, mouseX, mouseY, delta);
	}

	/** Drawn above the background but below the widgets (panels, labels). */
	protected void renderContent(class_332 graphics, int mouseX, int mouseY, float delta) {
	}

	/** Drawn above the widgets. */
	protected void renderForeground(class_332 graphics, int mouseX, int mouseY, float delta) {
	}

	@Override
	public void method_25420(class_332 graphics, int mouseX, int mouseY, float delta) {
		this.drawBackground(graphics, mouseX, mouseY, delta);
		this.renderContent(graphics, mouseX, mouseY, delta);
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
		super.method_25394(graphics, mouseX, mouseY, delta);
		this.renderForeground(graphics, mouseX, mouseY, delta);
	}
}
