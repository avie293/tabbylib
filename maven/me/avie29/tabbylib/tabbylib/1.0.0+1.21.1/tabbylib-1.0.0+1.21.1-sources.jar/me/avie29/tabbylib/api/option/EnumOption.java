package me.avie29.tabbylib.api.option;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import org.jspecify.annotations.Nullable;

import java.util.Locale;
import java.util.function.Function;
import net.minecraft.class_2561;

/**
 * One value out of an enum. Left click cycles forward, right click backwards.
 * Enum constants are translated as {@code config.<modid>.<key>.<constant in lowercase>} unless a formatter is set.
 */
public class EnumOption<E extends Enum<E>> extends Option<E> {
	private final Class<E> enumClass;
	private final @Nullable Function<E, class_2561> formatter;

	protected EnumOption(me.avie29.tabbylib.api.option.EnumOption.Builder<E> builder) {
		super(builder);
		this.enumClass = builder.enumClass;
		this.formatter = builder.formatter;
	}

	public static <E extends Enum<E>> me.avie29.tabbylib.api.option.EnumOption.Builder<E> builder(String key, E defaultValue) {
		return new me.avie29.tabbylib.api.option.EnumOption.Builder<>(key, defaultValue);
	}

	public E[] values() {
		return this.enumClass.getEnumConstants();
	}

	public E cycle(E current, int direction) {
		E[] values = this.values();
		return values[Math.floorMod(current.ordinal() + direction, values.length)];
	}

	public class_2561 valueText(E value) {
		if (this.formatter != null) {
			return this.formatter.apply(value);
		}
		String key = this.translationKey() + "." + value.name().toLowerCase(Locale.ROOT);
		return TranslationHelper.exists(key) ? class_2561.method_43471(key) : class_2561.method_43470(prettify(value.name()));
	}

	private static String prettify(String name) {
		String lower = name.replace('_', ' ').toLowerCase(Locale.ROOT);
		return Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
	}

	@Override
	public String formatValue(E value) {
		return this.valueText(value).getString();
	}

	@Override
	public JsonElement toJson(E value) {
		return new JsonPrimitive(value.name());
	}

	@Override
	public E fromJson(JsonElement json) {
		return Enum.valueOf(this.enumClass, json.getAsString());
	}

	public static class Builder<E extends Enum<E>> extends Option.Builder<E, me.avie29.tabbylib.api.option.EnumOption.Builder<E>> {
		private final Class<E> enumClass;
		private @Nullable Function<E, class_2561> formatter;

		protected Builder(String key, E defaultValue) {
			super(key, defaultValue);
			this.enumClass = defaultValue.getDeclaringClass();
		}

		public me.avie29.tabbylib.api.option.EnumOption.Builder<E> formatter(Function<E, class_2561> formatter) {
			this.formatter = formatter;
			return this;
		}

		@Override
		public EnumOption<E> build() {
			return new EnumOption<>(this);
		}
	}
}
