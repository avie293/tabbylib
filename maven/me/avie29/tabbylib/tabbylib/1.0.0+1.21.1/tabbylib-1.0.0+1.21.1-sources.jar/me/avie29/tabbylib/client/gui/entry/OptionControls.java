package me.avie29.tabbylib.client.gui.entry;

import me.avie29.tabbylib.api.option.BooleanOption;
import me.avie29.tabbylib.api.option.ColorOption;
import me.avie29.tabbylib.api.option.DoubleOption;
import me.avie29.tabbylib.api.option.EnumOption;
import me.avie29.tabbylib.api.option.HudPositionOption;
import me.avie29.tabbylib.api.option.IntOption;
import me.avie29.tabbylib.api.option.KeyBindOption;
import me.avie29.tabbylib.api.option.Option;
import me.avie29.tabbylib.api.option.StringListOption;
import me.avie29.tabbylib.api.option.StringOption;
import me.avie29.tabbylib.client.gui.ColorPickerScreen;
import me.avie29.tabbylib.client.gui.HudEditorScreen;
import me.avie29.tabbylib.client.gui.StringListScreen;
import me.avie29.tabbylib.client.gui.TabbyConfigScreen;
import me.avie29.tabbylib.client.gui.widget.ColorSwatch;
import me.avie29.tabbylib.client.gui.widget.TabbyButton;
import me.avie29.tabbylib.client.gui.widget.ValueSlider;
import me.avie29.tabbylib.compat.McCompat;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_3675;
import net.minecraft.class_5250;
import net.minecraft.class_7919;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.function.Function;

/** Creates the fitting control for each option type. */
public final class OptionControls {
	private static final int TEXT_COLOR = class_342.field_32196;
	private static final int ERROR_COLOR = 0xFFFF5555;

	private OptionControls() {
	}

	@SuppressWarnings({"unchecked", "rawtypes"})
	public static OptionControl create(Option<?> option, TabbyConfigScreen screen) {
		class_327 font = class_310.method_1551().field_1772;
		if (option instanceof BooleanOption bool) {
			return new BooleanControl(bool);
		}
		if (option instanceof IntOption number) {
			return number.isSlider()
				? new SliderControl(number.getMin(), number.getMax(), number.getStep(),
				() -> number.getPending(), value -> number.setPending((int) Math.round(value)), value -> number.valueText((int) Math.round(value)))
				: new TextControl<>(font, number, value -> Integer.toString(value), text -> {
				int parsed = Integer.parseInt(text.trim());
				return parsed >= number.getMin() && parsed <= number.getMax() ? parsed : null;
			});
		}
		if (option instanceof DoubleOption number) {
			return number.isSlider()
				? new SliderControl(number.getMin(), number.getMax(), number.getStep(),
				number::getPending, number::setPending, number::valueText)
				: new TextControl<>(font, number, number::formatValue, text -> {
				double parsed = Double.parseDouble(text.trim().replace(',', '.'));
				return parsed >= number.getMin() && parsed <= number.getMax() ? parsed : null;
			});
		}
		if (option instanceof StringOption string) {
			TextControl<String> control = new TextControl<>(font, string, Function.identity(), text -> string.isValid(text) ? text : null);
			control.box.method_1880(string.getMaxLength());
			if (string.getHint() != null) {
				control.box.method_47404(string.getHint());
			}
			return control;
		}
		if (option instanceof EnumOption enumOption) {
			return new EnumControl<>(enumOption);
		}
		if (option instanceof ColorOption color) {
			return new ColorControl(font, color, screen);
		}
		if (option instanceof KeyBindOption keyBind) {
			return new KeyBindControl(keyBind, screen);
		}
		if (option instanceof StringListOption list) {
			return new ButtonControl(
				() -> class_2561.method_43469("tabbylib.list.edit", list.getPending().size()),
				() -> screen.openSubScreen(new StringListScreen(screen, list)));
		}
		if (option instanceof HudPositionOption hud) {
			return new ButtonControl(
				() -> class_2561.method_43471("tabbylib.hud.edit"),
				() -> screen.openSubScreen(new HudEditorScreen(screen, hud)));
		}
		// Unknown option type from another mod: show the value read only
		ButtonControl fallback = new ButtonControl(() -> class_2561.method_43470(describe(option)), () -> {
		});
		fallback.button.field_22763 = false;
		return fallback;
	}

	private static <T> String describe(Option<T> option) {
		return option.formatValue(option.getPending());
	}

	// ---------------------------------------------------------------- boolean

	private static final class BooleanControl implements OptionControl {
		private final BooleanOption option;
		private final TabbyButton button;

		BooleanControl(BooleanOption option) {
			this.option = option;
			this.button = new TabbyButton(0, 20, class_2561.method_43473(), () -> {
				option.setPending(!option.getPending());
				this.refresh();
			});
			this.refresh();
		}

		@Override
		public List<? extends class_339> widgets() {
			return List.of(this.button);
		}

		@Override
		public void layout(int x, int y, int width, int height) {
			McCompat.setBounds(this.button, x, y, width, height);
		}

		@Override
		public void refresh() {
			boolean value = this.option.getPending();
			class_5250 text = this.option.valueText(value).method_27661();
			this.button.method_25355(text.method_27692(value ? class_124.field_1060 : class_124.field_1061));
		}
	}

	// ---------------------------------------------------------------- slider

	private static final class SliderControl implements OptionControl {
		private final java.util.function.DoubleSupplier getter;
		private final ValueSlider slider;

		SliderControl(double min, double max, double step, java.util.function.DoubleSupplier getter,
					  java.util.function.DoubleConsumer setter, java.util.function.DoubleFunction<class_2561> formatter) {
			this.getter = getter;
			this.slider = new ValueSlider(0, 20, min, max, step, getter.getAsDouble(), formatter, setter);
		}

		@Override
		public List<? extends class_339> widgets() {
			return List.of(this.slider);
		}

		@Override
		public void layout(int x, int y, int width, int height) {
			McCompat.setBounds(this.slider, x, y, width, height);
		}

		@Override
		public void refresh() {
			this.slider.setActualValue(this.getter.getAsDouble());
		}
	}

	// ---------------------------------------------------------------- text / numbers

	private static final class TextControl<T> implements OptionControl {
		private final Option<T> option;
		private final Function<T, String> toText;
		final class_342 box;
		private boolean updating;

		/**
		 * @param parser returns null (or throws) for invalid input
		 */
		TextControl(class_327 font, Option<T> option, Function<T, String> toText, Function<String, @Nullable T> parser) {
			this.option = option;
			this.toText = toText;
			this.box = new class_342(font, 0, 0, 150, 20, option.getName());
			this.box.method_1880(1024);
			this.box.method_1852(toText.apply(option.getPending()));
			this.box.method_1863(text -> {
				if (this.updating) {
					return;
				}
				T parsed;
				try {
					parsed = parser.apply(text);
				} catch (RuntimeException e) {
					parsed = null;
				}
				if (parsed != null) {
					option.setPending(parsed);
					this.box.method_1868(TEXT_COLOR);
				} else {
					this.box.method_1868(ERROR_COLOR);
				}
			});
		}

		@Override
		public List<? extends class_339> widgets() {
			return List.of(this.box);
		}

		@Override
		public void layout(int x, int y, int width, int height) {
			boolean resized = this.box.method_25368() != width - 2;
			McCompat.setBounds(this.box, x + 1, y + 1, width - 2, height - 2);
			if (resized && !this.box.method_25370()) {
				// Shows the start of the text again after the width changed
				McCompat.resetCursor(this.box);
			}
		}

		@Override
		public void refresh() {
			String text = this.toText.apply(this.option.getPending());
			if (!text.equals(this.box.method_1882())) {
				this.updating = true;
				this.box.method_1852(text);
				this.updating = false;
			}
			this.box.method_1868(TEXT_COLOR);
		}
	}

	// ---------------------------------------------------------------- enum

	private static final class EnumControl<E extends Enum<E>> implements OptionControl {
		private final EnumOption<E> option;
		private final TabbyButton button;

		EnumControl(EnumOption<E> option) {
			this.option = option;
			this.button = new TabbyButton(0, 20, class_2561.method_43473(), true, secondary -> {
				int direction = secondary ? -1 : 1;
				option.setPending(option.cycle(option.getPending(), direction));
				this.refresh();
			});
			this.refresh();
		}

		@Override
		public List<? extends class_339> widgets() {
			return List.of(this.button);
		}

		@Override
		public void layout(int x, int y, int width, int height) {
			McCompat.setBounds(this.button, x, y, width, height);
		}

		@Override
		public void refresh() {
			this.button.method_25355(this.option.valueText(this.option.getPending()));
		}
	}

	// ---------------------------------------------------------------- color

	private static final class ColorControl implements OptionControl {
		private final ColorOption option;
		private final ColorSwatch swatch;
		private final TextControl<Integer> text;

		ColorControl(class_327 font, ColorOption option, TabbyConfigScreen screen) {
			this.option = option;
			this.text = new TextControl<>(font, option, value -> ColorOption.toHex(value, option.hasAlpha()), input -> {
				Integer parsed = ColorOption.parseHex(input);
				if (parsed == null) {
					return null;
				}
				// "#RRGGBB" typed into an alpha field keeps full opacity, alpha is ignored without alpha support
				return option.hasAlpha() ? parsed : parsed | 0xFF000000;
			});
			this.swatch = new ColorSwatch(20, option::getPending, () -> screen.openSubScreen(
				new ColorPickerScreen(screen, option.getName(), option.getPending(), option.hasAlpha(), picked -> {
					option.setPending(picked);
					this.refresh();
				})));
		}

		@Override
		public List<? extends class_339> widgets() {
			return List.of(this.swatch, this.text.box);
		}

		@Override
		public void layout(int x, int y, int width, int height) {
			McCompat.setBounds(this.swatch, x, y, height, height);
			this.text.layout(x + height + 4, y, width - height - 4, height);
		}

		@Override
		public void refresh() {
			this.text.refresh();
		}
	}

	// ---------------------------------------------------------------- key binds

	public static final class KeyBindControl implements OptionControl {
		private final KeyBindOption option;
		private final TabbyButton button;
		private final TabbyConfigScreen screen;

		KeyBindControl(KeyBindOption option, TabbyConfigScreen screen) {
			this.option = option;
			this.screen = screen;
			this.button = new TabbyButton(0, 20, class_2561.method_43473(), () -> {
				screen.startKeyCapture(this);
				this.refresh();
			});
			this.refresh();
		}

		public void setKey(class_3675.class_306 key) {
			this.option.setPending(key);
			this.refresh();
		}

		@Override
		public List<? extends class_339> widgets() {
			return List.of(this.button);
		}

		@Override
		public void layout(int x, int y, int width, int height) {
			McCompat.setBounds(this.button, x, y, width, height);
			this.refresh();
		}

		@Override
		public void refresh() {
			class_3675.class_306 key = this.option.getPending();
			class_5250 text = key.method_27445().method_27661();
			if (this.screen.isCapturing(this)) {
				text = class_2561.method_43470("> ").method_10852(text.method_27695(class_124.field_1068, class_124.field_1073))
					.method_27693(" <").method_27692(class_124.field_1054);
			}
			List<class_2561> conflicts = this.conflicts(key);
			if (!conflicts.isEmpty() && !this.screen.isCapturing(this)) {
				text = class_2561.method_43470("[ ").method_10852(text).method_27693(" ]").method_27692(class_124.field_1061);
				this.button.method_47400(class_7919.method_47407(class_2561.method_43469("controls.keybinds.duplicateKeybinds",
					class_2564.method_37112(conflicts, class_2561.method_43470(", ")))));
			} else {
				this.button.method_47400(null);
			}
			this.button.method_25355(text);
		}

		/** Other key mappings on the same key. Like vanilla, two mappings that are both on their default key are fine. */
		private List<class_2561> conflicts(class_3675.class_306 key) {
			if (key.equals(class_3675.field_16237)) {
				return List.of();
			}
			class_304 own = this.option.getMapping();
			boolean ownDefault = key.method_1441().equals(own.method_1429().method_1441());
			String name = key.method_1441();
			List<class_2561> result = new java.util.ArrayList<>();
			for (class_304 other : class_310.method_1551().field_1690.field_1839) {
				if (other != own && other.method_1428().equals(name) && !(ownDefault && other.method_1427())) {
					result.add(class_2561.method_43471(other.method_1431()));
				}
			}
			return result;
		}
	}

	// ---------------------------------------------------------------- button that opens something

	private static final class ButtonControl implements OptionControl {
		private final java.util.function.Supplier<class_2561> text;
		private final TabbyButton button;

		ButtonControl(java.util.function.Supplier<class_2561> text, Runnable onPress) {
			this.text = text;
			this.button = new TabbyButton(0, 20, text.get(), onPress);
		}

		@Override
		public List<? extends class_339> widgets() {
			return List.of(this.button);
		}

		@Override
		public void layout(int x, int y, int width, int height) {
			McCompat.setBounds(this.button, x, y, width, height);
		}

		@Override
		public void refresh() {
			this.button.method_25355(this.text.get());
		}
	}
}
