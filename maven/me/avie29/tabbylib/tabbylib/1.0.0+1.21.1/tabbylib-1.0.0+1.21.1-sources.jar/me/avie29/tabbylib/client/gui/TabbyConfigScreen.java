package me.avie29.tabbylib.client.gui;

import me.avie29.tabbylib.TabbyLibConfig;
import me.avie29.tabbylib.api.ActionEntry;
import me.avie29.tabbylib.api.ConfigCategory;
import me.avie29.tabbylib.api.ConfigEntry;
import me.avie29.tabbylib.api.LabelEntry;
import me.avie29.tabbylib.api.OptionGroup;
import me.avie29.tabbylib.api.TabbyConfig;
import me.avie29.tabbylib.api.TabbyLibApi;
import me.avie29.tabbylib.api.option.Option;
import me.avie29.tabbylib.client.gui.entry.OptionControls;
import me.avie29.tabbylib.client.gui.widget.FlatTab;
import me.avie29.tabbylib.client.gui.widget.TabbyButton;
import me.avie29.tabbylib.compat.McCompat;
import me.avie29.tabbylib.compat.TabbyScreen;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_410;
import net.minecraft.class_437;
import net.minecraft.class_7919;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The TabbyLib config screen: mod list on the left, the options of the selected mod on the right (legacy variant).
 */
public class TabbyConfigScreen extends TabbyScreen {
	private static final int MARGIN = 8;
	private static final int GAP = 4;
	private static final int TOP = 24;
	private static final int FOOTER = 30;
	/** Wider screens get empty space at the sides, otherwise labels and controls drift too far apart. */
	private static final int MAX_WIDTH = 640;

	private final @Nullable class_437 parent;
	private final List<TabbyConfig> configs;
	private @Nullable TabbyConfig selected;
	private @Nullable ConfigCategory selectedCategory;
	private String search = "";

	private @Nullable ModListWidget modList;
	private @Nullable OptionListWidget optionList;
	private @Nullable class_342 searchBox;
	private final List<FlatTab> tabs = new ArrayList<>();
	private OptionControls.@Nullable KeyBindControl capturingKey;
	private String visibilitySignature = "";

	private double restoreScroll;
	private @Nullable class_2561 statusMessage;
	private long statusUntil;

	// Layout, computed in init()
	private int listX;
	private int listWidth;
	private int panelY;
	private int panelBottom;
	private int contentX;
	private int contentWidth;

	public TabbyConfigScreen(@Nullable class_437 parent, @Nullable String modId) {
		super(class_2561.method_43471("tabbylib.screen.title"));
		this.parent = parent;
		this.configs = TabbyLibApi.getConfigs();
		if (modId != null) {
			this.selected = TabbyLibApi.getConfig(modId);
		}
		if (this.selected == null && !this.configs.isEmpty()) {
			this.selected = this.configs.get(0);
		}
	}

	// ---------------------------------------------------------------- layout

	@Override
	protected void method_25426() {
		TabbyLibConfig.ListWidth widthSetting = TabbyLibConfig.LIST_WIDTH.getPending();
		int usableWidth = Math.min(this.field_22789 - MARGIN * 2, MAX_WIDTH);
		this.listX = (this.field_22789 - usableWidth) / 2;
		this.listWidth = class_3532.method_15340(usableWidth / 4, widthSetting.min, widthSetting.max);
		this.panelY = TOP;
		this.panelBottom = this.field_22790 - FOOTER;
		this.contentX = this.listX + this.listWidth + GAP;
		this.contentWidth = this.listX + usableWidth - this.contentX;

		this.modList = new ModListWidget(this.field_22787, this.listX + 2, this.panelY + 3, this.listWidth - 4,
			this.panelBottom - this.panelY - 6, this.configs, this::selectConfig);
		this.method_37063(this.modList);

		int searchWidth = Math.min(130, this.contentWidth / 3);
		this.searchBox = new class_342(this.field_22793, this.contentX + this.contentWidth - searchWidth - 6, this.panelY + 5, searchWidth, 16,
			class_2561.method_43471("tabbylib.search"));
		this.searchBox.method_47404(class_2561.method_43471("tabbylib.search").method_27695(class_124.field_1080, class_124.field_1056));
		this.searchBox.method_1852(this.search);
		this.searchBox.method_1863(text -> {
			this.search = text;
			this.rebuildTabs();
			this.rebuildOptions();
		});
		this.method_37063(this.searchBox);

		this.optionList = new OptionListWidget(this.field_22787, this, this.contentX + 2, this.panelY + 25, this.contentWidth - 4, 10);
		this.method_37063(this.optionList);

		// Footer buttons
		int buttonWidth = Math.min(100, (this.field_22789 - MARGIN * 2 - GAP * 3) / 4);
		int totalWidth = buttonWidth * 4 + GAP * 3;
		int x = (this.field_22789 - totalWidth) / 2;
		int y = this.field_22790 - FOOTER + 5;
		TabbyButton reset = new TabbyButton(buttonWidth, 20, class_2561.method_43471("tabbylib.button.reset"), this::resetSelected);
		reset.method_47400(class_7919.method_47407(class_2561.method_43471("tabbylib.button.reset.tooltip")));
		TabbyButton discard = new TabbyButton(buttonWidth, 20, class_2561.method_43471("tabbylib.button.discard"), this::discardAll);
		TabbyButton save = new TabbyButton(buttonWidth, 20, class_2561.method_43471("tabbylib.button.save"), this::saveAll);
		TabbyButton done = new TabbyButton(buttonWidth, 20, class_2561.method_43471("tabbylib.button.done"), () -> {
			this.saveAll();
			this.closeScreen();
		});
		for (TabbyButton button : List.of(reset, discard, save, done)) {
			button.method_48229(x, y);
			x += buttonWidth + GAP;
			this.method_37063(button);
		}

		if (this.selected != null) {
			this.modList.select(this.selected);
		}
		this.rebuildTabs();
		this.rebuildOptions();
		this.optionList.setScroll(this.restoreScroll);
		this.restoreScroll = 0;
	}

	private void selectConfig(TabbyConfig config) {
		if (this.selected != config) {
			this.selected = config;
			this.selectedCategory = null;
			this.rebuildTabs();
			this.rebuildOptions();
			if (this.optionList != null) {
				this.optionList.setScroll(0);
			}
		}
	}

	private void rebuildTabs() {
		this.tabs.forEach(this::method_37066);
		this.tabs.clear();
		if (this.selected == null) {
			return;
		}
		List<ConfigCategory> categories = this.selected.getCategories();
		if (this.selectedCategory == null || !categories.contains(this.selectedCategory)) {
			this.selectedCategory = categories.get(0);
		}
		if (categories.size() > 1 && this.search.isBlank()) {
			int x = this.contentX + 6;
			int available = this.contentWidth - 12;
			int maxTabWidth = available / categories.size();
			for (ConfigCategory category : categories) {
				int tabWidth = Math.min(maxTabWidth, this.field_22793.method_27525(category.getName()) + 12);
				FlatTab tab = new FlatTab(tabWidth, 14, category.getName(), () -> this.selectedCategory == category, () -> {
					this.selectedCategory = category;
					this.rebuildOptions();
					if (this.optionList != null) {
						this.optionList.setScroll(0);
					}
				});
				tab.method_48229(x, this.panelY + 24);
				x += tabWidth + 2;
				this.tabs.add(this.method_37063(tab));
			}
		}
	}

	private int optionListTop() {
		return this.panelY + (this.tabs.isEmpty() ? 25 : 41);
	}

	/** Recreates the option rows, e.g. after changing category, search or collapsing a group. */
	public void rebuildOptions() {
		if (this.optionList == null) {
			return;
		}
		double scroll = this.optionList.scroll();
		int top = this.optionListTop();
		this.optionList.setBounds(this.contentX + 2, top, this.contentWidth - 4, this.panelBottom - top - 3);
		this.optionList.clear();
		this.visibilitySignature = this.computeVisibilitySignature();

		if (this.selected == null) {
			this.optionList.addText(class_2561.method_43471("tabbylib.no_mods"), false);
			return;
		}

		String query = this.search.trim().toLowerCase(Locale.ROOT);
		if (!query.isEmpty()) {
			this.addSearchResults(query);
		} else if (this.selectedCategory != null) {
			this.addEntries(this.selectedCategory.getEntries(), false);
		}
		this.optionList.setScroll(scroll);
	}

	private void addEntries(List<ConfigEntry> entries, boolean indented) {
		for (ConfigEntry entry : entries) {
			if (entry instanceof Option<?> option) {
				if (option.isVisible()) {
					this.optionList.addOption(option, indented);
				}
			} else if (entry instanceof OptionGroup group) {
				this.optionList.addGroup(group);
				if (!group.isCollapsed()) {
					this.addEntries(group.getEntries(), true);
				}
			} else if (entry instanceof LabelEntry label) {
				this.optionList.addText(label.text(), indented);
			} else if (entry instanceof ActionEntry action) {
				this.optionList.addAction(action, indented);
			}
		}
	}

	private void addSearchResults(String query) {
		boolean any = false;
		for (ConfigCategory category : this.selected.getCategories()) {
			boolean headerAdded = false;
			for (Option<?> option : category.getOptions()) {
				if (!option.isVisible() || !matches(option, query)) {
					continue;
				}
				if (!headerAdded) {
					this.optionList.addHeader(category.getName());
					headerAdded = true;
				}
				this.optionList.addOption(option, false);
				any = true;
			}
		}
		if (!any) {
			this.optionList.addText(class_2561.method_43471("tabbylib.search.empty").method_27692(class_124.field_1080), false);
		}
	}

	private static boolean matches(Option<?> option, String query) {
		if (option.getName().getString().toLowerCase(Locale.ROOT).contains(query)
			|| option.getKey().toLowerCase(Locale.ROOT).contains(query)) {
			return true;
		}
		class_2561 tooltip = option.getTooltip();
		return tooltip != null && tooltip.getString().toLowerCase(Locale.ROOT).contains(query);
	}

	/** Which options are visible right now. When it changes (visibleWhen) the list is rebuilt. */
	private String computeVisibilitySignature() {
		if (this.selected == null) {
			return "";
		}
		StringBuilder builder = new StringBuilder();
		for (Option<?> option : this.selected.getOptions()) {
			builder.append(option.isVisible() ? '1' : '0');
		}
		return builder.toString();
	}

	@Override
	public void method_25393() {
		if (!this.computeVisibilitySignature().equals(this.visibilitySignature)) {
			this.rebuildOptions();
		}
	}

	// ---------------------------------------------------------------- actions

	private void resetSelected() {
		if (this.selected != null) {
			this.selected.resetPendingToDefaults();
			this.refreshAfterChange();
		}
	}

	private void discardAll() {
		this.configs.forEach(TabbyConfig::discard);
		this.refreshAfterChange();
		this.showStatus(class_2561.method_43471("tabbylib.status.discarded"));
	}

	private void saveAll() {
		boolean changed = false;
		boolean restart = false;
		for (TabbyConfig config : this.configs) {
			if (config.hasChanges()) {
				changed = true;
				restart |= config.commit();
			} else {
				config.discard();
			}
		}
		this.refreshAfterChange();
		if (restart) {
			this.showStatus(class_2561.method_43471("tabbylib.status.restart").method_27692(class_124.field_1061));
		} else if (changed) {
			this.showStatus(class_2561.method_43471("tabbylib.status.saved").method_27692(class_124.field_1060));
		}
	}

	private void refreshAfterChange() {
		// Settings like the list width only apply after a re-layout, which also refreshes all controls
		this.rememberScroll();
		this.method_41843();
	}

	private void rememberScroll() {
		this.restoreScroll = this.optionList != null ? this.optionList.scroll() : 0;
	}

	private void showStatus(class_2561 message) {
		this.statusMessage = message;
		this.statusUntil = class_156.method_658() + 3000;
	}

	public void openSubScreen(class_437 screen) {
		this.rememberScroll();
		McCompat.setScreen(screen);
	}

	private boolean hasUnsavedChanges() {
		for (TabbyConfig config : this.configs) {
			if (config.hasChanges()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void method_25419() {
		if (this.hasUnsavedChanges() && TabbyLibConfig.CONFIRM_UNSAVED.get()) {
			McCompat.setScreen(new class_410(save -> {
				if (save) {
					this.saveAll();
				} else {
					this.configs.forEach(TabbyConfig::discard);
				}
				this.closeScreen();
			}, class_2561.method_43471("tabbylib.unsaved.title"), class_2561.method_43471("tabbylib.unsaved.message"),
				class_2561.method_43471("tabbylib.button.save"), class_2561.method_43471("tabbylib.button.discard")));
			return;
		}
		this.configs.forEach(TabbyConfig::discard);
		this.closeScreen();
	}

	private void closeScreen() {
		McCompat.setScreen(this.parent);
	}

	// ---------------------------------------------------------------- key binding capture

	public void startKeyCapture(OptionControls.KeyBindControl control) {
		OptionControls.KeyBindControl previous = this.capturingKey;
		this.capturingKey = control;
		if (previous != null && previous != control) {
			previous.refresh();
		}
	}

	public boolean isCapturing(OptionControls.KeyBindControl control) {
		return this.capturingKey == control;
	}

	private void finishKeyCapture(class_3675.class_306 key) {
		OptionControls.KeyBindControl control = this.capturingKey;
		this.capturingKey = null;
		if (control != null) {
			control.setKey(key);
		}
	}

	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers) {
		if (this.capturingKey != null) {
			this.finishKeyCapture(keyCode == class_3675.field_31958 ? class_3675.field_16237 : class_3675.method_15985(keyCode, scanCode));
			return true;
		}
		// Ctrl + F focuses the search
		if (keyCode == class_3675.field_32020 && class_437.method_25441() && this.searchBox != null) {
			this.method_25395(this.searchBox);
			return true;
		}
		// Ctrl + S saves
		if (keyCode == class_3675.field_31908 && class_437.method_25441()) {
			this.saveAll();
			return true;
		}
		return super.method_25404(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (this.capturingKey != null) {
			this.finishKeyCapture(class_3675.class_307.field_1672.method_1447(button));
			return true;
		}
		return super.method_25402(mouseX, mouseY, button);
	}

	// ---------------------------------------------------------------- rendering

	@Override
	protected void renderContent(class_332 graphics, int mouseX, int mouseY, float delta) {
		Panel.draw(graphics, this.listX, this.panelY, this.listWidth, this.panelBottom - this.panelY);
		Panel.draw(graphics, this.contentX, this.panelY, this.contentWidth, this.panelBottom - this.panelY);

		graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 8, 0xFFFFFFFF);

		if (this.selected != null) {
			int accent = TabbyLibConfig.accentColor();
			int titleMaxWidth = this.contentWidth - (this.searchBox != null ? this.searchBox.method_25368() : 0) - 20;
			graphics.method_51430(this.field_22793, OptionListWidget.clip(this.field_22793, this.selected.getDisplayName().method_27661().method_27692(class_124.field_1067), titleMaxWidth),
				this.contentX + 7, this.panelY + 9, accent, true);
			int lineY = this.optionListTop() - 2;
			graphics.method_25294(this.contentX + 4, lineY, this.contentX + this.contentWidth - 4, lineY + 1, 0x40FFFFFF);
		}
	}

	@Override
	protected void renderForeground(class_332 graphics, int mouseX, int mouseY, float delta) {
		if (this.statusMessage != null) {
			if (class_156.method_658() < this.statusUntil) {
				int textWidth = this.field_22793.method_27525(this.statusMessage);
				int x = this.contentX + this.contentWidth - textWidth;
				graphics.method_51439(this.field_22793, this.statusMessage, x, 8, 0xFFFFFFFF, true);
			} else {
				this.statusMessage = null;
			}
		}
	}
}
