package me.avie29.tabbylib.mixin;

import me.avie29.tabbylib.client.OptionsButton;
import net.minecraft.class_2561;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_7845;
import net.minecraft.class_8021;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * Adds the "Tabby Config" button as a full width row below the vanilla option buttons.
 * The button becomes part of the vanilla button grid, so it moves with it when the screen is re-arranged
 * (resizing, coming back from a sub screen). Works without MixinExtras, so every loader can use it.
 */
@Mixin(class_429.class)
public abstract class OptionsScreenMixin extends class_437 {
	protected OptionsScreenMixin(class_2561 title) {
		super(title);
	}

	@ModifyArg(
		method = "init",
		at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/layouts/HeaderAndFooterLayout;addToContents(Lnet/minecraft/client/gui/layouts/LayoutElement;)Lnet/minecraft/client/gui/layouts/LayoutElement;")
	)
	private class_8021 tabbylib$addConfigButton(class_8021 contents) {
		if (OptionsButton.enabled() && contents instanceof class_7845 grid) {
			int[] children = {0};
			grid.method_48227(child -> children[0]++);
			// The vanilla grid has 2 columns, the new row spans both
			int nextRow = (children[0] + 1) / 2;
			grid.method_46453(OptionsButton.create(this), nextRow, 0, 1, 2);
		}
		return contents;
	}
}
