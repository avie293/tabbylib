package me.avie29.tabbylib.api.option;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import net.minecraft.class_2561;
import org.jspecify.annotations.Nullable;

/** On / off toggle. */
public class BooleanOption extends Option<Boolean> {
	private final @Nullable class_2561 trueText;
	private final @Nullable class_2561 falseText;

	protected BooleanOption(me.avie29.tabbylib.api.option.BooleanOption.Builder builder) {
		super(builder);
		this.trueText = builder.trueText;
		this.falseText = builder.falseText;
	}

	public static me.avie29.tabbylib.api.option.BooleanOption.Builder builder(String key, boolean defaultValue) {
		return new me.avie29.tabbylib.api.option.BooleanOption.Builder(key, defaultValue);
	}

	/** Text shown on the toggle button, e.g. "Shown" / "Hidden". Defaults to On / Off. */
	public class_2561 valueText(boolean value) {
		if (value) {
			return this.trueText != null ? this.trueText : class_2561.method_43471("tabbylib.value.on");
		}
		return this.falseText != null ? this.falseText : class_2561.method_43471("tabbylib.value.off");
	}

	@Override
	public String formatValue(Boolean value) {
		return this.valueText(value).getString();
	}

	@Override
	public JsonElement toJson(Boolean value) {
		return new JsonPrimitive(value);
	}

	@Override
	public Boolean fromJson(JsonElement json) {
		return json.getAsBoolean();
	}

	public static class Builder extends Option.Builder<Boolean, me.avie29.tabbylib.api.option.BooleanOption.Builder> {
		private @Nullable class_2561 trueText;
		private @Nullable class_2561 falseText;

		protected Builder(String key, boolean defaultValue) {
			super(key, defaultValue);
		}

		public me.avie29.tabbylib.api.option.BooleanOption.Builder valueText(class_2561 trueText, class_2561 falseText) {
			this.trueText = trueText;
			this.falseText = falseText;
			return this;
		}

		@Override
		public BooleanOption build() {
			return new BooleanOption(this);
		}
	}
}
