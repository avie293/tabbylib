package me.avie29.tabbylib.compat;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4265;

/**
 * Scrolling list of rows with widgets, without vanilla background and separators (1.21.1 variant).
 * All rows have the same height in this Minecraft version.
 */
public abstract class TabbyList<E extends class_4265.class_4266<E>> extends class_4265<E> {
	protected TabbyList(class_310 minecraft, int x, int y, int width, int height, int rowHeight) {
		super(minecraft, width, height, y, rowHeight);
		this.method_46421(x);
	}

	public void setBounds(int x, int y, int width, int height) {
		this.method_57714(width, height, y);
		this.method_46421(x);
	}

	public int rowHeight() {
		return this.field_22741;
	}

	public void clear() {
		this.method_25339();
	}

	public void add(E entry) {
		this.method_25321(entry);
	}

	public double scroll() {
		return this.method_25341();
	}

	public void setScroll(double amount) {
		this.method_25307(amount);
	}

	public int maxScroll() {
		return this.method_25331();
	}

	@Override
	public int method_25322() {
		return this.field_22758 - 14;
	}

	@Override
	public int method_25342() {
		return this.method_46426() + 4;
	}

	@Override
	protected int method_25329() {
		return this.method_55442() - 7;
	}

	@Override
	protected void method_57715(class_332 graphics) {
	}

	@Override
	protected void method_57713(class_332 graphics) {
	}
}
