package me.avie29.tabbylib.client.gui.widget;

import me.avie29.tabbylib.TabbyLibConfig;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_6382;
import java.util.function.BooleanSupplier;

/** Category tab: plain text with an accent colored underline when selected. */
public class FlatTab extends class_4264 {
	private final BooleanSupplier selected;
	private final Runnable onPress;

	public FlatTab(int width, int height, class_2561 message, BooleanSupplier selected, Runnable onPress) {
		super(0, 0, width, height, message);
		this.selected = selected;
		this.onPress = onPress;
	}

	@Override
	public void method_25306() {
		this.onPress.run();
	}

	@Override
	protected void method_48579(class_332 graphics, int mouseX, int mouseY, float delta) {
		class_327 font = class_310.method_1551().field_1772;
		boolean isSelected = this.selected.getAsBoolean();
		int x = this.method_46426();
		int y = this.method_46427();
		int accent = TabbyLibConfig.accentColor();

		if (isSelected) {
			graphics.method_25294(x, y, x + this.field_22758, y + this.field_22759, 0x40000000);
			graphics.method_25294(x, y + this.field_22759 - 2, x + this.field_22758, y + this.field_22759, accent);
		} else if (this.method_25367()) {
			graphics.method_25294(x, y, x + this.field_22758, y + this.field_22759, 0x30FFFFFF);
		}

		int color = isSelected ? 0xFFFFFFFF : this.method_25367() ? 0xFFE0E0E0 : 0xFFA0A0A0;
		class_2561 text = this.method_25369();
		String clipped = font.method_27523(text.getString(), this.field_22758 - 4);
		class_2561 shown = clipped.length() < text.getString().length() ? class_2561.method_43470(clipped) : text;
		graphics.method_27534(font, shown, x + this.field_22758 / 2, y + (this.field_22759 - 8) / 2 - 1, color);
	}

	@Override
	protected void method_47399(class_6382 output) {
		this.method_37021(output);
	}
}
