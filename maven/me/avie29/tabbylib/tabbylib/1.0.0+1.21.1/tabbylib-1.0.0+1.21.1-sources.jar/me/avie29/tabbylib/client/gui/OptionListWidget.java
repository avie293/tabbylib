package me.avie29.tabbylib.client.gui;

import me.avie29.tabbylib.TabbyLibConfig;
import me.avie29.tabbylib.api.ActionEntry;
import me.avie29.tabbylib.api.OptionGroup;
import me.avie29.tabbylib.api.option.Option;
import me.avie29.tabbylib.client.gui.entry.OptionControl;
import me.avie29.tabbylib.client.gui.entry.OptionControls;
import me.avie29.tabbylib.client.gui.widget.TabbyButton;
import me.avie29.tabbylib.compat.McCompat;
import me.avie29.tabbylib.compat.TabbyList;
import net.minecraft.class_1109;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3417;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_6379;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_7919;
import java.util.ArrayList;
import java.util.List;

/** Scrollable list of option rows on the right side of the config screen (legacy variant, fixed row height). */
public class OptionListWidget extends TabbyList<OptionListWidget.Row> {
	public static final int ROW_HEIGHT = 24;
	private static final int INDENT = 10;
	private static final int RESET_WIDTH = 20;
	private static final int LINES_PER_ROW = 2;

	private final TabbyConfigScreen screen;

	public OptionListWidget(class_310 minecraft, TabbyConfigScreen screen, int x, int y, int width, int height) {
		super(minecraft, x, y, width, height, ROW_HEIGHT);
		this.screen = screen;
	}

	public void addOption(Option<?> option, boolean indented) {
		this.add(new OptionRow(option, OptionControls.create(option, this.screen), indented));
	}

	public void addGroup(OptionGroup group) {
		this.add(new GroupRow(group));
	}

	public void addAction(ActionEntry action, boolean indented) {
		this.add(new ActionRow(action, indented));
	}

	public void addHeader(class_2561 text) {
		this.add(new HeaderRow(text));
	}

	/** Long text is split over several rows, because all rows have the same height here. */
	public void addText(class_2561 text, boolean indented) {
		class_327 font = this.field_22740.field_1772;
		int wrapWidth = Math.max(40, this.method_25322() - 8 - (indented ? INDENT : 0));
		List<class_5481> lines = font.method_1728(text, wrapWidth);
		for (int i = 0; i < lines.size(); i += LINES_PER_ROW) {
			this.add(new TextRow(lines.subList(i, Math.min(lines.size(), i + LINES_PER_ROW)), indented));
		}
	}

	/** Updates all controls from the pending values (after reset / discard). */
	public void refreshControls() {
		for (Row row : this.method_25396()) {
			if (row instanceof OptionRow optionRow) {
				optionRow.control.refresh();
			}
		}
	}

	// ---------------------------------------------------------------- rows

	public abstract static class Row extends class_4265.class_4266<Row> {
	}

	private final class OptionRow extends Row {
		private final Option<?> option;
		private final OptionControl control;
		private final TabbyButton resetButton;
		private final List<class_339> widgets = new ArrayList<>();
		private final boolean indented;

		OptionRow(Option<?> option, OptionControl control, boolean indented) {
			this.option = option;
			this.control = control;
			this.indented = indented;
			this.resetButton = new TabbyButton(RESET_WIDTH, 20, class_2561.method_43470("↺"), () -> {
				option.resetPending();
				control.refresh();
			});
			this.resetButton.method_47400(class_7919.method_47407(class_2561.method_43469("tabbylib.reset.tooltip",
				class_2561.method_43470(describeDefault(option)).method_27692(class_124.field_1054))));
			this.widgets.addAll(control.widgets());
			this.widgets.add(this.resetButton);
		}

		@Override
		public void method_25343(class_332 graphics, int index, int rowTop, int rowLeft, int rowWidth, int rowHeight,
						   int mouseX, int mouseY, boolean hovered, float delta) {
			class_327 font = OptionListWidget.this.field_22740.field_1772;
			int left = rowLeft + (this.indented ? INDENT : 0);
			int right = rowLeft + rowWidth;
			int top = rowTop;
			int height = 20;
			int controlWidth = Math.min(150, Math.max(80, (right - left) * 45 / 100));
			int controlX = right - RESET_WIDTH - 2 - controlWidth;

			boolean enabled = this.option.isEnabled();
			this.control.setActive(enabled);
			this.control.layout(controlX, top, controlWidth, height);
			this.resetButton.method_48229(right - RESET_WIDTH, top);
			this.resetButton.field_22763 = enabled && !this.option.isPendingDefault();

			if (hovered) {
				graphics.method_25294(rowLeft - 2, rowTop - 2, right + 2, rowTop + ROW_HEIGHT - 2, 0x18FFFFFF);
			}

			// Modified marker
			if (this.option.isDirty()) {
				graphics.method_25294(left - 3, top + 3, left - 1, top + height - 3, TabbyLibConfig.accentColor());
			}

			class_5250 name = this.option.getName().method_27661();
			if (this.option.requiresRestart()) {
				name.method_10852(class_2561.method_43470(" *").method_27692(class_124.field_1061));
			}
			int labelWidth = controlX - left - 6;
			int color = !enabled ? 0xFF808080 : this.option.isDirty() ? 0xFFFFE08A : 0xFFFFFFFF;
			graphics.method_51430(font, clip(font, name, labelWidth), left + 2, top + (height - 8) / 2, color, true);

			for (class_339 widget : this.widgets) {
				widget.method_25394(graphics, mouseX, mouseY, delta);
			}

			boolean overLabel = mouseX >= left && mouseX < controlX - 4 && mouseY >= rowTop && mouseY < rowTop + height;
			class_437 current = McCompat.currentScreen();
			if (overLabel && current != null) {
				current.method_47414(this.tooltipLines(font));
			}
		}

		private List<class_5481> tooltipLines(class_327 font) {
			List<class_5481> lines = new ArrayList<>();
			lines.add(this.option.getName().method_27661().method_27692(class_124.field_1068).method_30937());
			class_2561 tooltip = this.option.getTooltip();
			if (tooltip != null) {
				lines.addAll(font.method_1728(tooltip.method_27661().method_27692(class_124.field_1080), 220));
			}
			if (this.option.requiresRestart()) {
				lines.addAll(font.method_1728(class_2561.method_43471("tabbylib.requires_restart").method_27692(class_124.field_1061), 220));
			}
			if (!this.option.isEnabled()) {
				lines.addAll(font.method_1728(class_2561.method_43471("tabbylib.disabled").method_27692(class_124.field_1063), 220));
			}
			lines.add(class_2561.method_43469("tabbylib.default", describeDefault(this.option)).method_27692(class_124.field_1063).method_30937());
			return lines;
		}

		@Override
		public List<? extends class_364> method_25396() {
			return this.widgets;
		}

		@Override
		public List<? extends class_6379> method_37025() {
			return this.widgets;
		}
	}

	private final class GroupRow extends Row {
		private final OptionGroup group;

		GroupRow(OptionGroup group) {
			this.group = group;
		}

		@Override
		public void method_25343(class_332 graphics, int index, int rowTop, int rowLeft, int rowWidth, int rowHeight,
						   int mouseX, int mouseY, boolean hovered, float delta) {
			class_327 font = OptionListWidget.this.field_22740.field_1772;
			int accent = TabbyLibConfig.accentColor();
			int lineY = rowTop + rowHeight - 1;
			graphics.method_25294(rowLeft, lineY, rowLeft + rowWidth, lineY + 1, (accent & 0x00FFFFFF) | 0x80000000);
			String arrow = this.group.isCollapsed() ? "▶ " : "▼ ";
			class_2561 text = class_2561.method_43470(arrow).method_27694(style -> style.method_36139(accent & 0xFFFFFF))
				.method_10852(this.group.getName().method_27661().method_27692(class_124.field_1067));
			graphics.method_51439(font, text, rowLeft + 2, rowTop + 6, hovered ? 0xFFFFFFFF : 0xFFE0E0E0, true);
			class_437 current = McCompat.currentScreen();
			if (hovered && this.group.getDescription() != null && current != null) {
				current.method_47414(font.method_1728(this.group.getDescription(), 220));
			}
		}

		@Override
		public boolean method_25402(double mouseX, double mouseY, int button) {
			if (button == class_3675.field_32000) {
				this.group.setCollapsed(!this.group.isCollapsed());
				OptionListWidget.this.field_22740.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
				OptionListWidget.this.screen.rebuildOptions();
				return true;
			}
			return false;
		}

		@Override
		public List<? extends class_364> method_25396() {
			return List.of();
		}

		@Override
		public List<? extends class_6379> method_37025() {
			return List.of(new TextNarratable(this.group.getName()));
		}
	}

	private final class ActionRow extends Row {
		private final ActionEntry action;
		private final TabbyButton button;
		private final boolean indented;

		ActionRow(ActionEntry action, boolean indented) {
			this.action = action;
			this.indented = indented;
			this.button = new TabbyButton(0, 20, action.buttonText(), action.action());
			if (action.tooltip() != null) {
				this.button.method_47400(class_7919.method_47407(action.tooltip()));
			}
		}

		@Override
		public void method_25343(class_332 graphics, int index, int rowTop, int rowLeft, int rowWidth, int rowHeight,
						   int mouseX, int mouseY, boolean hovered, float delta) {
			class_327 font = OptionListWidget.this.field_22740.field_1772;
			int left = rowLeft + (this.indented ? INDENT : 0);
			int right = rowLeft + rowWidth;
			int buttonWidth = Math.min(150, Math.max(80, (right - left) * 45 / 100)) + RESET_WIDTH + 2;
			int buttonX = right - buttonWidth;
			McCompat.setBounds(this.button, buttonX, rowTop, buttonWidth, 20);
			graphics.method_51430(font, clip(font, this.action.name(), buttonX - left - 6), left + 2, rowTop + 6, 0xFFFFFFFF, true);
			this.button.method_25394(graphics, mouseX, mouseY, delta);
		}

		@Override
		public List<? extends class_364> method_25396() {
			return List.of(this.button);
		}

		@Override
		public List<? extends class_6379> method_37025() {
			return List.of(this.button);
		}
	}

	private final class HeaderRow extends Row {
		private final class_2561 text;

		HeaderRow(class_2561 text) {
			this.text = text;
		}

		@Override
		public void method_25343(class_332 graphics, int index, int rowTop, int rowLeft, int rowWidth, int rowHeight,
						   int mouseX, int mouseY, boolean hovered, float delta) {
			class_327 font = OptionListWidget.this.field_22740.field_1772;
			graphics.method_51439(font, this.text, rowLeft + 2, rowTop + 8, TabbyLibConfig.accentColor(), true);
		}

		@Override
		public List<? extends class_364> method_25396() {
			return List.of();
		}

		@Override
		public List<? extends class_6379> method_37025() {
			return List.of(new TextNarratable(this.text));
		}
	}

	private final class TextRow extends Row {
		private final List<class_5481> lines;
		private final boolean indented;

		TextRow(List<class_5481> lines, boolean indented) {
			this.lines = List.copyOf(lines);
			this.indented = indented;
		}

		@Override
		public void method_25343(class_332 graphics, int index, int rowTop, int rowLeft, int rowWidth, int rowHeight,
						   int mouseX, int mouseY, boolean hovered, float delta) {
			class_327 font = OptionListWidget.this.field_22740.field_1772;
			int x = rowLeft + 2 + (this.indented ? INDENT : 0);
			int y = rowTop + 1;
			for (class_5481 line : this.lines) {
				graphics.method_51430(font, line, x, y, 0xFFB0B0B0, false);
				y += font.field_2000 + 1;
			}
		}

		@Override
		public List<? extends class_364> method_25396() {
			return List.of();
		}

		@Override
		public List<? extends class_6379> method_37025() {
			return List.of();
		}
	}

	// ---------------------------------------------------------------- helpers

	private static <T> String describeDefault(Option<T> option) {
		return option.formatValue(option.getDefault());
	}

	static class_5481 clip(class_327 font, class_2561 text, int width) {
		if (font.method_27525(text) <= width) {
			return text.method_30937();
		}
		String ellipsis = "...";
		String clipped = font.method_27523(text.getString(), Math.max(0, width - font.method_1727(ellipsis)));
		return class_2561.method_43470(clipped + ellipsis).method_27696(text.method_10866()).method_30937();
	}

	/** Lets the narrator read rows that have no widgets. */
	private record TextNarratable(class_2561 text) implements class_6379 {
		@Override
		public class_6380 method_37018() {
			return class_6380.field_33785;
		}

		@Override
		public void method_37020(class_6382 output) {
			output.method_37034(class_6381.field_33788, this.text);
		}
	}
}
