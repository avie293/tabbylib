package me.avie29.tabbylib.compat;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4280;

/** Selectable list without vanilla background and separators (1.21.1 variant). */
public abstract class TabbySelectionList<E extends class_4280.class_4281<E>> extends class_4280<E> {
	protected TabbySelectionList(class_310 minecraft, int x, int y, int width, int height, int rowHeight) {
		super(minecraft, width, height, y, rowHeight);
		this.method_46421(x);
	}

	public void add(E entry) {
		this.method_25321(entry);
	}

	@Override
	public int method_25322() {
		return this.field_22758 - 14;
	}

	@Override
	public int method_25342() {
		return this.method_46426() + 4;
	}

	@Override
	protected int method_25329() {
		return this.method_55442() - 7;
	}

	@Override
	protected void method_57715(class_332 graphics) {
	}

	@Override
	protected void method_57713(class_332 graphics) {
	}
}
