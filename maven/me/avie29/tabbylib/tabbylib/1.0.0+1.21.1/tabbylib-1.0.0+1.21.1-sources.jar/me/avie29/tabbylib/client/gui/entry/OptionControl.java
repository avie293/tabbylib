package me.avie29.tabbylib.client.gui.entry;

import java.util.List;
import net.minecraft.class_339;

/** The widgets that edit one option, placed on the right side of an option row. */
public interface OptionControl {
	List<? extends class_339> widgets();

	/** Positions the widgets inside the given area. */
	void layout(int x, int y, int width, int height);

	/** Updates the widgets from the pending value, e.g. after "reset". */
	void refresh();

	default void setActive(boolean active) {
		for (class_339 widget : this.widgets()) {
			widget.field_22763 = active;
		}
	}
}
