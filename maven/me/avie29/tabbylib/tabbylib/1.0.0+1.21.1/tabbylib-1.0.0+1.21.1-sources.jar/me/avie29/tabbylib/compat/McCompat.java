package me.avie29.tabbylib.compat;

import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_437;
import org.jspecify.annotations.Nullable;

/**
 * The few Minecraft calls that differ between versions (1.21.1 variant). Each Minecraft version gets its own
 * copy of the compat package (see tools/ports.py), everything else stays identical.
 */
public final class McCompat {
	private McCompat() {
	}

	public static void setScreen(@Nullable class_437 screen) {
		class_310.method_1551().method_1507(screen);
	}

	public static @Nullable class_437 currentScreen() {
		return class_310.method_1551().field_1755;
	}

	public static class_2960 id(String namespace, String path) {
		return class_2960.method_60655(namespace, path);
	}

	public static class_1043 texture(class_1011 image) {
		return new class_1043(image);
	}

	public static void setBounds(class_339 widget, int x, int y, int width, int height) {
		widget.method_55444(width, height, x, y);
	}

	/** Scrolls a text field back to the start of its text. */
	public static void resetCursor(class_342 box) {
		box.method_1875(0);
		box.method_1884(0);
	}
}
