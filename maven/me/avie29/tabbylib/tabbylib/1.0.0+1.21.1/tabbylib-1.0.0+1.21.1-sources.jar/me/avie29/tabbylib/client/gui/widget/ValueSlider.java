package me.avie29.tabbylib.client.gui.widget;

import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_357;

/** Slider for a number range. Snaps to the step and shows a formatted value. */
public class ValueSlider extends class_357 {
	private final double min;
	private final double max;
	private final double step;
	private final DoubleFunction<class_2561> formatter;
	private final DoubleConsumer onChange;

	public ValueSlider(int width, int height, double min, double max, double step, double initial,
					   DoubleFunction<class_2561> formatter, DoubleConsumer onChange) {
		super(0, 0, width, height, class_2561.method_43473(), 0);
		this.min = min;
		this.max = max;
		this.step = step;
		this.formatter = formatter;
		this.onChange = onChange;
		this.setActualValue(initial);
	}

	public double getActualValue() {
		double raw = this.min + this.field_22753 * (this.max - this.min);
		if (this.step > 0) {
			raw = this.min + Math.round((raw - this.min) / this.step) * this.step;
		}
		return class_3532.method_15350(raw, this.min, this.max);
	}

	/** Moves the handle without calling the change handler. */
	public void setActualValue(double actual) {
		this.field_22753 = this.max > this.min ? class_3532.method_15350((actual - this.min) / (this.max - this.min), 0, 1) : 0;
		this.method_25346();
	}

	@Override
	protected void method_25346() {
		this.method_25355(this.formatter.apply(this.getActualValue()));
	}

	@Override
	protected void method_25344() {
		this.onChange.accept(this.getActualValue());
	}
}
