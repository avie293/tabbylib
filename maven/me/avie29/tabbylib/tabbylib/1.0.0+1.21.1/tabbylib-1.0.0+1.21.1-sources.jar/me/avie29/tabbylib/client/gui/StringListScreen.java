package me.avie29.tabbylib.client.gui;

import me.avie29.tabbylib.api.option.StringListOption;
import me.avie29.tabbylib.client.gui.widget.TabbyButton;
import me.avie29.tabbylib.compat.McCompat;
import me.avie29.tabbylib.compat.TabbyList;
import me.avie29.tabbylib.compat.TabbyScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_6379;
import net.minecraft.class_7919;
import java.util.ArrayList;
import java.util.List;

/** Edits a {@link StringListOption}: one text field per entry, with add / remove / move buttons (legacy variant). */
public class StringListScreen extends TabbyScreen {
	private final class_437 parent;
	private final StringListOption option;
	private final List<String> values;
	private EntryList list;

	private int panelX;
	private int panelY;
	private int panelWidth;
	private int panelHeight;

	public StringListScreen(class_437 parent, StringListOption option) {
		super(option.getName());
		this.parent = parent;
		this.option = option;
		this.values = new ArrayList<>(option.getPending());
	}

	@Override
	protected void method_25426() {
		this.panelWidth = class_3532.method_15340(this.field_22789 - 40, 200, 340);
		this.panelHeight = this.field_22790 - 40;
		this.panelX = (this.field_22789 - this.panelWidth) / 2;
		this.panelY = 20;

		double scroll = this.list != null ? this.list.scroll() : 0;
		this.list = new EntryList(this.field_22787, this.panelX + 2, this.panelY + 22, this.panelWidth - 4, this.panelHeight - 52);
		this.method_37063(this.list);
		this.list.setScroll(scroll);

		int buttonY = this.panelY + this.panelHeight - 26;
		int buttonWidth = (this.panelWidth - 28) / 3;
		TabbyButton addButton = new TabbyButton(buttonWidth, 20, class_2561.method_43471("tabbylib.list.add"), () -> {
			this.values.add("");
			this.method_41843();
			this.list.setScroll(this.list.maxScroll());
		});
		addButton.field_22763 = this.values.size() < this.option.getMaxEntries();
		TabbyButton cancel = new TabbyButton(buttonWidth, 20, class_2561.method_43471("gui.cancel"), this::method_25419);
		TabbyButton done = new TabbyButton(buttonWidth, 20, class_2561.method_43471("gui.done"), () -> {
			this.option.setPending(this.values.stream().filter(value -> !value.isBlank()).toList());
			this.method_25419();
		});
		int x = this.panelX + 10;
		for (TabbyButton button : List.of(addButton, cancel, done)) {
			button.method_48229(x, buttonY);
			x += buttonWidth + 4;
			this.method_37063(button);
		}
	}

	@Override
	public void method_25419() {
		McCompat.setScreen(this.parent);
	}

	@Override
	protected void renderContent(class_332 graphics, int mouseX, int mouseY, float delta) {
		Panel.draw(graphics, this.panelX, this.panelY, this.panelWidth, this.panelHeight);
		graphics.method_51430(this.field_22793, OptionListWidget.clip(this.field_22793, this.field_22785, this.panelWidth - 20), this.panelX + 10, this.panelY + 8, 0xFFFFFFFF, true);
		String count = this.values.size() + " / " + this.option.getMaxEntries();
		graphics.method_51433(this.field_22793, count, this.panelX + this.panelWidth - 10 - this.field_22793.method_1727(count), this.panelY + 8, 0xFF808080, false);
	}

	private class EntryList extends TabbyList<EntryList.Row> {
		EntryList(class_310 minecraft, int x, int y, int width, int height) {
			super(minecraft, x, y, width, height, 24);
			for (int i = 0; i < StringListScreen.this.values.size(); i++) {
				this.add(new Row(i));
			}
		}

		private class Row extends class_4265.class_4266<Row> {
			private final class_342 box;
			private final TabbyButton up;
			private final TabbyButton down;
			private final TabbyButton remove;

			Row(int index) {
				List<String> values = StringListScreen.this.values;
				this.box = new class_342(StringListScreen.this.field_22793, 0, 0, 100, 18, class_2561.method_43470("#" + (index + 1)));
				this.box.method_1880(1024);
				this.box.method_1852(values.get(index));
				this.box.method_1863(text -> values.set(index, text));
				this.up = new TabbyButton(16, 20, class_2561.method_43470("▲"), () -> this.move(index, -1));
				this.up.field_22763 = index > 0;
				this.down = new TabbyButton(16, 20, class_2561.method_43470("▼"), () -> this.move(index, 1));
				this.down.field_22763 = index < values.size() - 1;
				this.remove = new TabbyButton(20, 20, class_2561.method_43470("✕"), () -> {
					values.remove(index);
					StringListScreen.this.method_41843();
				});
				this.remove.method_47400(class_7919.method_47407(class_2561.method_43471("tabbylib.list.remove")));
			}

			private void move(int index, int direction) {
				List<String> values = StringListScreen.this.values;
				int target = index + direction;
				if (target >= 0 && target < values.size()) {
					values.set(index, values.set(target, values.get(index)));
					StringListScreen.this.method_41843();
				}
			}

			@Override
			public void method_25343(class_332 graphics, int index, int rowTop, int rowLeft, int rowWidth, int rowHeight,
							   int mouseX, int mouseY, boolean hovered, float delta) {
				int right = rowLeft + rowWidth;
				this.remove.method_48229(right - 20, rowTop);
				this.down.method_48229(right - 38, rowTop);
				this.up.method_48229(right - 56, rowTop);
				McCompat.setBounds(this.box, rowLeft + 1, rowTop + 1, right - 60 - rowLeft - 2, 18);
				this.box.method_25394(graphics, mouseX, mouseY, delta);
				this.up.method_25394(graphics, mouseX, mouseY, delta);
				this.down.method_25394(graphics, mouseX, mouseY, delta);
				this.remove.method_25394(graphics, mouseX, mouseY, delta);
			}

			@Override
			public List<? extends class_364> method_25396() {
				return List.of(this.box, this.up, this.down, this.remove);
			}

			@Override
			public List<? extends class_6379> method_37025() {
				return List.of(this.box, this.up, this.down, this.remove);
			}
		}
	}
}
