package me.avie29.tabbylib.client.gui.widget;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_4264;
import net.minecraft.class_437;
import net.minecraft.class_6382;

/**
 * Vanilla styled button that also reacts to right clicks.
 * The handler receives true for the "secondary" action: right click or Shift + click.
 */
public class TabbyButton extends class_4264 {
	private final Consumer<Boolean> onPress;
	private final boolean rightClick;

	public TabbyButton(int width, int height, class_2561 message, boolean rightClick, Consumer<Boolean> onPress) {
		super(0, 0, width, height, message);
		this.onPress = onPress;
		this.rightClick = rightClick;
	}

	public TabbyButton(int width, int height, class_2561 message, Runnable onPress) {
		this(width, height, message, false, secondary -> onPress.run());
	}

	@Override
	public void method_25306() {
		this.onPress.accept(class_437.method_25442());
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (button == class_3675.field_32002 && this.rightClick && this.field_22763 && this.field_22764 && this.method_25405(mouseX, mouseY)) {
			this.method_25354(class_310.method_1551().method_1483());
			this.onPress.accept(true);
			return true;
		}
		return super.method_25402(mouseX, mouseY, button);
	}

	@Override
	protected void method_47399(class_6382 output) {
		this.method_37021(output);
	}
}
